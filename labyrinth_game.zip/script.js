document.addEventListener("DOMContentLoaded", () => {
    const player = document.getElementById("player");
    const gameContainer = document.getElementById("game-container");
    const gridSize = 5; // 5x5 grid
    let playerPosition = { x: 0, y: 0 };

    // Initialize grid
    for (let i = 0; i < gridSize * gridSize; i++) {
        const room = document.createElement("div");
        room.id = `room-${i}`;
        gameContainer.appendChild(room);
    }

    function updatePlayerPosition() {
        player.style.transform = `translate(${playerPosition.x * 100}px, ${playerPosition.y * 100}px)`;
        checkRoom();
    }

    function checkRoom() {
        const roomNumber = playerPosition.y * gridSize + playerPosition.x;
        const currentRoom = document.getElementById(`room-${roomNumber}`);
        currentRoom.style.backgroundColor = getRandomColor();
        currentRoom.innerHTML = `Room ${roomNumber + 1}`;
    }

    function getRandomColor() {
        const letters = "0123456789ABCDEF";
        let color = "#";
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    document.addEventListener("keydown", (e) => {
        switch (e.key) {
            case "ArrowUp":
                if (playerPosition.y > 0) playerPosition.y--;
                break;
            case "ArrowDown":
                if (playerPosition.y < gridSize - 1) playerPosition.y++;
                break;
            case "ArrowLeft":
                if (playerPosition.x > 0) playerPosition.x--;
                break;
            case "ArrowRight":
                if (playerPosition.x < gridSize - 1) playerPosition.x++;
                break;
        }
        updatePlayerPosition();
    });

    updatePlayerPosition();
});
